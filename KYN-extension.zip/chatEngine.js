// ─── KYN Chat Engine ─────────────────────────────────────────────────────────
// Keyword-based intent detection + neighborhood-data-aware response generation.

const KYNChatEngine = (() => {

  // ── Topic detection ─────────────────────────────────────────────────────────
  // Ordered most-specific → least-specific to avoid false positives.

  const TOPIC_PATTERNS = [
    { topic: "greeting",      re: /^\s*(hi+|hey+|hello|howdy|sup|what'?s up|greetings)/i },
    { topic: "thanks",        re: /\b(thanks?|thank you|thx|cheers|appreciate)\b/i },
    { topic: "construction",  re: /\b(construct|building work|crane|develop|scaffold|jackhammer|dig|road ?work|being built|new build)\b/i },
    { topic: "schools",       re: /\b(school|educat|elementar|kindergarten|pre-?k|daycare|preschool|kids.*school|school.*kid)\b/i },
    { topic: "safety",        re: /\b(safe|unsafe|crime|dangerous|sketch|rough|mugg|theft|rob|break-?in|police|secure|walk at night|at night)\b/i },
    { topic: "parking",       re: /\b(park(ing)?|garage|street spot|car|vehicle|permit park)\b/i },
    { topic: "transit",       re: /\b(commut|transit|train|the el|cta|l line|red line|blue line|brown line|pink line|metra|bus route|uber|lyft|downtown|the loop|drive time|get to work|how far)\b/i },
    { topic: "nightlife",     re: /\b(nightlife|bar scene|club|nightclub|going out|night scene|drinks?\b|party scene)\b/i },
    { topic: "noise",         re: /\b(nois[ey]|loud|quiet|sound|keep me up|sleep|peaceful|silent)\b/i },
    { topic: "restaurants",   re: /\b(restaurant|food scene|eat|dine|cuisine|coffee|cafe|brunch|lunch|dinner|groceri|whole foods|trader joe)\b/i },
    { topic: "walkability",   re: /\b(walk(able|ability)?|pedestrian|stroll|on foot|errands|walk score)\b/i },
    { topic: "families",      re: /\b(famil(y|ies)|kids?|children|stroller|playground|raise a family|good for kids|young kids)\b/i },
    { topic: "feel",          re: /\b(vibe|feel|atmospher|character|personalit|communit|culture|what'?s it like|like living|like the area)\b/i },
    { topic: "cost",          re: /\b(cost|expens|rent|afford|price|budget|cheap|pricey|worth( it)?|how much)\b/i },
    { topic: "dogs",          re: /\b(dog|pet|cat|animal|pup|leash|dog park|pet.?friendly)\b/i },
  ];

  function detectTopic(question) {
    for (const { topic, re } of TOPIC_PATTERNS) {
      if (re.test(question)) return topic;
    }
    return "fallback";
  }

  // ── Data helpers ────────────────────────────────────────────────────────────

  function getCat(data, id) {
    return data.categories.find(c => c.id === id);
  }

  function scoreAdj(score, map) {
    // map: array of [minScore, label] ascending — returns label for highest matching min
    let result = map[0][1];
    for (const [min, label] of map) {
      if (score >= min) result = label;
    }
    return result;
  }

  function walkScore(data) {
    const detail = getCat(data, "feel").detail;
    const m = detail.match(/Walk Score[^\d]*(\d+)/i);
    return m ? parseInt(m[1], 10) : null;
  }

  function transitLines(data) {
    const text = (data.aiSummary + " " + getCat(data, "feel").detail).toLowerCase();
    const found = [];
    if (/red line/.test(text))   found.push("the Red Line");
    if (/blue line/.test(text))  found.push("the Blue Line");
    if (/brown line/.test(text)) found.push("the Brown Line");
    if (/pink line/.test(text))  found.push("the Pink Line");
    if (/green line/.test(text)) found.push("the Green Line");
    if (/metra/.test(text))      found.push("Metra");
    return found;
  }

  // ── Response generators ─────────────────────────────────────────────────────

  const R = {

    greeting(data) {
      return `Hey! I'm your KYN guide for <strong>${data.neighborhood}</strong>. Ask me anything — safety, schools, commute, parking, noise, restaurants, what it's like for families, or the general vibe. What do you want to know?`;
    },

    thanks() {
      return `Happy to help! Feel free to ask about anything else — I have detailed data on safety, noise, schools, transit, construction, parking, walkability, and more.`;
    },

    safety(data) {
      const cat = getCat(data, "safety");
      const adj = scoreAdj(cat.score, [
        [1, "a genuine concern that deserves careful consideration"],
        [2, "something to be mindful of"],
        [3, "moderate — about average for Chicago"],
        [4, "quite good"],
        [5, "excellent — among the best in the city"],
      ]);
      const tip = cat.score >= 4
        ? "Most residents feel comfortable walking around both day and night on the main corridors."
        : cat.score === 3
        ? "It's generally fine during daylight hours. Late at night on side streets, standard Chicago awareness applies."
        : "I'd strongly recommend researching your specific block — safety varies a lot within the neighborhood.";
      return `Safety in <strong>${data.neighborhood}</strong> is ${adj} — we rate it <strong>${cat.score}/5</strong>. ${cat.detail} ${tip}`;
    },

    noise(data) {
      const cat = getCat(data, "noise");
      const adj = scoreAdj(cat.score, [
        [1, "significantly noisy — this is one of Chicago's louder neighborhoods"],
        [2, "quite loud in places, especially on weekends"],
        [3, "moderately active — a mix of lively and quiet depending on the block"],
        [4, "relatively calm for an urban neighborhood"],
        [5, "very quiet — one of the most peaceful you'll find in Chicago"],
      ]);
      return `<strong>${data.neighborhood}</strong> tends to be ${adj} — noise scores <strong>${cat.score}/5</strong> in our data. ${cat.detail}`;
    },

    schools(data) {
      const cat = getCat(data, "schools");
      const adj = scoreAdj(cat.score, [
        [1, "limited"],
        [2, "below average"],
        [3, "decent"],
        [4, "strong"],
        [5, "exceptional — among Chicago's best"],
      ]);
      return `The school picture in <strong>${data.neighborhood}</strong> is ${adj} — we rate it <strong>${cat.score}/5</strong>. ${cat.detail}`;
    },

    construction(data) {
      const cat = getCat(data, "construction");
      // Score is inverted: 5 = minimal disruption, 1 = heavy construction
      const adj = scoreAdj(cat.score, [
        [1, "very heavy — this is one of Chicago's most active construction zones right now"],
        [2, "notable — there's active construction that will affect daily life"],
        [3, "moderate — scattered projects, nothing neighborhood-defining"],
        [4, "light — only minor work underway"],
        [5, "minimal — very quiet on the construction front"],
      ]);
      return `Construction disruption in <strong>${data.neighborhood}</strong> is currently ${adj} (rated <strong>${cat.score}/5</strong>, where 5 = least disruption). ${cat.detail}`;
    },

    parking(data) {
      const ws = walkScore(data);
      const density = !ws
        ? "a typical Chicago neighborhood"
        : ws >= 95 ? "extremely dense — street parking is scarce and competitive"
        : ws >= 90 ? "very walkable and dense — parking takes effort, especially evenings"
        : ws >= 80 ? "moderately dense — parking is findable with some patience"
        : "less dense — parking is generally more available than in core neighborhoods";

      const specific =
        ["River North", "Streeterville", "Gold Coast", "West Loop"].includes(data.neighborhood)
          ? `In <strong>${data.neighborhood}</strong>, most residents use building garages or monthly lots. Reliable street parking is essentially nonexistent on weekends.`
          : data.neighborhood === "Wrigleyville"
          ? `<strong>Wrigleyville</strong> has extensive permit-only zones that block street parking during Cubs games — 81+ times a year. If you have a car, a garage is almost mandatory.`
          : `Many residents get by fine without a car given ${data.neighborhood}'s transit access, but if you're driving, budget time on weekend evenings to find a spot.`;

      return `<strong>${data.neighborhood}</strong> is ${density}${ws ? ` (Walk Score ${ws})` : ""}. ${specific}`;
    },

    transit(data) {
      const lines = transitLines(data);
      const ws = walkScore(data);
      const lineDesc = lines.length
        ? `<strong>${data.neighborhood}</strong> is served by ${lines.join(" and ")}`
        : `<strong>${data.neighborhood}</strong> has CTA bus access throughout`;
      const walkNote = ws ? ` With a Walk Score of ${ws}, most daily errands are doable on foot.` : "";
      return `${lineDesc}.${walkNote} The downtown Loop is typically 15–30 minutes depending on your exact address. For the best commute, prioritize units within 3–4 blocks of an L station — the difference in commute time and daily convenience is significant.`;
    },

    nightlife(data) {
      const noiseCat = getCat(data, "noise");
      const feelCat  = getCat(data, "feel");
      if (noiseCat.score <= 2) {
        return `<strong>${data.neighborhood}</strong> has a very active nightlife scene — which directly explains the noise score of ${noiseCat.score}/5. ${noiseCat.detail} If the bar and club scene is what you're after, it's right there. If you're trying to avoid it, look at units on side streets or above the 6th floor.`;
      } else if (noiseCat.score === 3) {
        return `<strong>${data.neighborhood}</strong> has a moderate going-out scene — enough that there's always something to do, but not so intense that it defines the neighborhood. ${feelCat.detail.split(".")[0]}. It strikes a reasonable balance for most residents.`;
      } else {
        return `<strong>${data.neighborhood}</strong> isn't really a nightlife hub — which is a genuine plus for many residents who live here. ${feelCat.detail.split(".")[0]}. For a big night out, you're a short Uber or L ride from everything Chicago has to offer.`;
      }
    },

    restaurants(data) {
      const feelCat = getCat(data, "feel");
      const sentences = feelCat.detail.split(/(?<=[.!?])\s+/);
      const foodLine  = sentences.find(s => /restaurant|food|eat|dine|cuisine|cafe|coffee|bar|shop|boutique/i.test(s));
      const outro = feelCat.score >= 4
        ? "Locals are generally very well-served by what's walkable."
        : "You may supplement with trips to neighboring areas for specific cuisines or specialty groceries.";
      return `${foodLine || `<strong>${data.neighborhood}</strong> has a dining and retail scene that reflects its character.`} The neighborhood scores <strong>${feelCat.score}/5</strong> on overall feel, which factors in food and amenity access. ${outro}`;
    },

    walkability(data) {
      const ws  = walkScore(data);
      const cat = getCat(data, "feel");
      const adj = !ws ? "reasonably walkable"
        : ws >= 95 ? "a true walker's paradise"
        : ws >= 90 ? "extremely walkable"
        : ws >= 85 ? "very walkable"
        : ws >= 75 ? "quite walkable with most errands on foot"
        : "moderately walkable, with some car or transit dependence";
      return `<strong>${data.neighborhood}</strong> is ${adj}${ws ? ` — Walk Score <strong>${ws}</strong>` : ""}. ${cat.detail}`;
    },

    families(data) {
      const sCat = getCat(data, "schools");
      const fCat = getCat(data, "feel");
      const adj  = scoreAdj(sCat.score, [
        [1, "challenging for families with school-age children"],
        [2, "below average for families — school options are limited"],
        [3, "decent for families — workable with some planning"],
        [4, "a solid family neighborhood"],
        [5, "excellent for families — one of Chicago's best"],
      ]);
      return `<strong>${data.neighborhood}</strong> is ${adj} — schools score <strong>${sCat.score}/5</strong>. ${sCat.detail} On the broader livability side: ${fCat.summary.toLowerCase()}`;
    },

    feel(data) {
      const cat = getCat(data, "feel");
      return `${cat.detail} <strong>${data.neighborhood}</strong> scores <strong>${cat.score}/5</strong> on neighborhood feel. In a nutshell: ${data.aiSummary.split(".")[0].toLowerCase()}.`;
    },

    cost(data) {
      const tier = scoreAdj(data.overallScore, [
        [1,   "one of Chicago's more affordable neighborhoods — the value reflects what's still developing"],
        [3.5, "mid-range for Chicago — solid value for what you're getting"],
        [4.0, "mid-to-upper range — you're paying for established amenities and desirability"],
        [4.2, "one of Chicago's pricier neighborhoods — but residents consistently say it's worth it"],
      ]);
      const noiseDiscount = getCat(data, "noise").score <= 2
        ? " Units closer to entertainment corridors often price slightly lower — something to factor in if you can tolerate noise."
        : "";
      return `<strong>${data.neighborhood}</strong> sits at ${tier}. Zillow's listing price is your best real-time signal, but as a rule, units farther from transit and entertainment tend to be more affordable — and quieter.${noiseDiscount}`;
    },

    dogs(data) {
      const fCat = getCat(data, "feel");
      const ws   = walkScore(data);
      const good = fCat.score >= 4 && (ws || 0) >= 85;
      if (good) {
        return `<strong>${data.neighborhood}</strong> is very dog-friendly.${ws ? ` With a Walk Score of ${ws}, you'll have no shortage of varied walking routes.` : ""} ${fCat.score >= 5 ? "It's the kind of neighborhood where people know their neighbors — and their neighbors' dogs." : "Active sidewalks and parks make it easy to keep a dog well-exercised."} Check the Chicago Park District site for the nearest off-leash area.`;
      }
      return `<strong>${data.neighborhood}</strong> is manageable for dogs — the walkability helps.${ws ? ` Walk Score is ${ws}.` : ""} Off-leash space may require a short trip. The Chicago Park District website has the current list of dog-friendly parks and beaches near the neighborhood.`;
    },

    fallback(data) {
      const suggestions = ["safety", "noise levels", "the schools", "transit and commute", "parking", "what it's like for families", "the local vibe and restaurants"];
      const pick = suggestions[Math.floor(Math.abs(Math.sin(Date.now())) * suggestions.length)];
      return `Great question — I want to give you accurate info for <strong>${data.neighborhood}</strong>. Try asking me about ${pick}, or anything else like construction activity, nightlife, walkability, or cost. I'll give you a detailed answer based on our neighborhood data.`;
    },
  };

  // ── Public API ──────────────────────────────────────────────────────────────

  return {
    getResponse(question, data) {
      const topic = detectTopic(question);
      const fn = R[topic] || R.fallback;
      try {
        return fn(data);
      } catch (_) {
        return R.fallback(data);
      }
    },
  };

})();
