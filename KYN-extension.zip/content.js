(function () {
  if (document.getElementById("kyn-sidebar")) return;
  if (!window.location.pathname.match(/\/homedetails\//)) return;

  // ─── Address extraction ───────────────────────────────────────────────────

  function extractAddressText() {
    const selectors = [
      '[data-testid="home-details-summary-headline"]',
      '[class*="summary-headline"]',
      '[class*="homeDetailsSummary"] h1',
      '[class*="hdp__sc"] h1',
      'h1[class*="Text"]',
      'h1',
    ];
    for (const sel of selectors) {
      const el = document.querySelector(sel);
      if (el && el.textContent.trim().length > 5) return el.textContent.trim();
    }
    const crumbs = document.querySelectorAll('[class*="breadcrumb"], nav[aria-label*="breadcrumb"] a');
    if (crumbs.length) return Array.from(crumbs).map(b => b.textContent.trim()).join(" ");
    return "";
  }

  function extractZipFromUrl() {
    const m = window.location.pathname.match(/\b(606\d{2})\b/);
    return m ? m[1] : null;
  }

  function extractAddressFromUrl() {
    const m = window.location.pathname.match(/\/homedetails\/([^/]+)/);
    return m ? decodeURIComponent(m[1]).toLowerCase() : "";
  }

  // ─── Neighborhood matching ────────────────────────────────────────────────

  function matchNeighborhoodKey(addressText, urlSlug, zipCode) {
    const haystack = (addressText + " " + urlSlug).toLowerCase();
    for (const rule of KYN_KEYWORD_RULES) {
      for (const term of rule.terms) {
        if (haystack.includes(term)) return rule.key;
      }
    }
    if (zipCode && KYN_ZIP_MAP[zipCode]) return KYN_ZIP_MAP[zipCode];
    return null;
  }

  // ─── Dot builders ────────────────────────────────────────────────────────

  function buildDots(score, max = 5) {
    let h = '<span class="kyn-dots">';
    for (let i = 1; i <= max; i++)
      h += `<span class="kyn-dot${i <= score ? " kyn-dot--filled" : ""}"></span>`;
    return h + "</span>";
  }

  function buildOverallDots(score) {
    const filled = Math.round(score);
    let h = '<span class="kyn-overall-dots">';
    for (let i = 1; i <= 5; i++)
      h += `<span class="kyn-dot kyn-dot--lg${i <= filled ? " kyn-dot--filled" : ""}"></span>`;
    return h + "</span>";
  }

  // ─── Card / quote builders ────────────────────────────────────────────────

  function buildCategoryCard(cat) {
    const id = `kyn-card-${cat.id}`;
    return `
      <div class="kyn-card" id="${id}">
        <button class="kyn-card__header" aria-expanded="false" aria-controls="${id}-detail">
          <span class="kyn-card__icon">${cat.icon}</span>
          <span class="kyn-card__label">${cat.label}</span>
          ${buildDots(cat.score)}
          <span class="kyn-card__chevron">▾</span>
        </button>
        <div class="kyn-card__summary">${cat.summary}</div>
        <div class="kyn-card__detail" id="${id}-detail" hidden>
          <p>${cat.detail}</p>
          <div class="kyn-card__source">Source: ${cat.source}</div>
        </div>
      </div>`;
  }

  function buildQuote(q) {
    return `
      <div class="kyn-quote">
        <div class="kyn-quote__text">"${q.text}"</div>
        <div class="kyn-quote__meta">
          <span class="kyn-quote__author">${q.author}</span>
          <span class="kyn-quote__sep">·</span>
          <span class="kyn-quote__source">${q.source}</span>
          <span class="kyn-quote__sep">·</span>
          <span class="kyn-quote__time">${q.timeAgo}</span>
        </div>
      </div>`;
  }

  // ─── Main sidebar HTML ────────────────────────────────────────────────────

  function buildScrollContent(data, detectedAddress) {
    const addrNote = detectedAddress
      ? `<div class="kyn-detected-address">${detectedAddress}</div>`
      : "";
    const welcomeMsg = `Hey! Ask me anything about <strong>${data.neighborhood}</strong> — safety, schools, parking, commute, nightlife, walkability, cost, or what it's really like to live here.`;
    return `
      <div class="kyn-header">
        <div class="kyn-header__top">
          <span class="kyn-logo">KYN</span>
          <div class="kyn-header__controls">
            <button class="kyn-gear-btn" id="kyn-gear-btn" aria-label="Settings">
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <circle cx="12" cy="12" r="3"/>
                <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/>
              </svg>
            </button>
            <button class="kyn-close" id="kyn-close-btn" aria-label="Close KYN panel">✕</button>
          </div>
        </div>
        <div class="kyn-header__location">
          <span class="kyn-neighborhood">${data.neighborhood}</span>
          <span class="kyn-city">${data.city}</span>
        </div>
        ${addrNote}
        <div class="kyn-header__score">
          ${buildOverallDots(data.overallScore)}
          <span class="kyn-score-label">${data.overallScore}/5 Overall</span>
        </div>
      </div>

      <div class="kyn-ai-summary">
        <div class="kyn-ai-summary__label">
          <span class="kyn-ai-icon">✦</span> AI Neighborhood Summary
        </div>
        <p class="kyn-ai-summary__text">${data.aiSummary}</p>
      </div>

      <div class="kyn-section-title">Neighborhood Intelligence</div>
      <div class="kyn-cards">
        ${data.categories.map(buildCategoryCard).join("")}
      </div>

      <div class="kyn-section-title">Resident Voices</div>
      <div class="kyn-quotes">
        ${data.residentQuotes.map(buildQuote).join("")}
      </div>

      <div class="kyn-section-title kyn-section-title--chat">
        <span>Ask a Resident</span>
        <span class="kyn-chat-badge">AI</span>
      </div>
      <div class="kyn-chat-history" id="kyn-chat-history">
        <div class="kyn-message kyn-message--bot">
          <div class="kyn-message__avatar">KYN</div>
          <div class="kyn-message__bubble">${welcomeMsg}</div>
        </div>
      </div>

      <div class="kyn-footer">
        Data for <strong>${data.neighborhood}</strong> · Updated May 2025
      </div>`;
  }

  function buildLimitedScrollContent(detectedAddress, zipCode) {
    const hint = detectedAddress || (zipCode ? `ZIP ${zipCode}` : "this address");
    return `
      <div class="kyn-header kyn-header--limited">
        <div class="kyn-header__top">
          <span class="kyn-logo">KYN</span>
          <button class="kyn-close" id="kyn-close-btn" aria-label="Close KYN panel">✕</button>
        </div>
        <div class="kyn-header__location">
          <span class="kyn-neighborhood">Neighborhood Unknown</span>
          <span class="kyn-city">Chicago, IL</span>
        </div>
      </div>

      <div class="kyn-limited-state">
        <div class="kyn-limited-state__icon">📍</div>
        <div class="kyn-limited-state__title">Limited Data Available</div>
        <p class="kyn-limited-state__body">
          KYN couldn't identify a covered neighborhood for <strong>${hint}</strong>.
        </p>
        <p class="kyn-limited-state__body">
          KYN covers 20 Chicago neighborhoods: Lincoln Park, Wicker Park, Logan Square,
          River North, Bucktown, Wrigleyville, Hyde Park, Pilsen, Andersonville, Lakeview,
          Old Town, Gold Coast, Streeterville, South Loop, West Loop, Humboldt Park,
          Bridgeport, Ravenswood, Rogers Park, and Uptown.
        </p>
        <div class="kyn-limited-state__hint">
          If this listing is in one of these neighborhoods, the address on the page may not
          contain a recognizable neighborhood name or ZIP code.
        </div>
      </div>

      <div class="kyn-footer">KYN · Know Your Neighborhood · May 2025</div>`;
  }

  // ─── Personalization: banner ──────────────────────────────────────────────

  function insertPersonalizeBanner(sidebar, data) {
    const existing = sidebar.querySelector("#kyn-personalize-banner");
    if (existing) { existing.style.display = ""; return; }

    const banner = document.createElement("div");
    banner.id = "kyn-personalize-banner";
    banner.className = "kyn-personalize-banner";
    banner.innerHTML = `
      <div class="kyn-personalize-banner__icon">🎯</div>
      <div class="kyn-personalize-banner__body">
        <div class="kyn-personalize-banner__title">Get your personal match score</div>
        <div class="kyn-personalize-banner__sub">4 quick questions, tailored results.</div>
      </div>
      <div class="kyn-personalize-banner__actions">
        <button class="kyn-banner-btn kyn-banner-btn--primary" id="kyn-personalize-btn">
          Personalize KYN
        </button>
        <button class="kyn-banner-btn kyn-banner-btn--ghost" id="kyn-skip-btn">
          Skip
        </button>
      </div>`;

    // Insert before the AI summary (first thing after the header)
    const aiSummary = sidebar.querySelector(".kyn-ai-summary");
    if (aiSummary) aiSummary.parentNode.insertBefore(banner, aiSummary);

    banner.querySelector("#kyn-personalize-btn").addEventListener("click", () => {
      banner.style.display = "none";
      showOnboardingOverlay(sidebar, data, {
        isUpdate: false,
        onComplete: (prefs) => { banner.remove(); insertMatchScore(sidebar, data, prefs); },
        onCancel:   ()      => { banner.style.display = ""; },
      });
    });

    banner.querySelector("#kyn-skip-btn").addEventListener("click", () => {
      KYNPrefs.save("skipped", null);
      banner.classList.add("kyn-personalize-banner--out");
      setTimeout(() => banner.remove(), 280);
    });
  }

  // ─── Personalization: match score card ───────────────────────────────────

  function insertMatchScore(sidebar, data, prefs) {
    // Remove any existing instance
    const prev = sidebar.querySelector("#kyn-match-score");
    if (prev) prev.remove();

    const score       = KYNPrefs.calculateMatch(data, prefs);
    const explanation = KYNPrefs.getExplanation(score, data, prefs);
    const tier        = KYNPrefs.scoreTier(score);

    const el = document.createElement("div");
    el.id = "kyn-match-score";
    el.className = `kyn-match-score kyn-match--${tier}`;
    el.innerHTML = `
      <div class="kyn-match-score__top">
        <div class="kyn-match-score__numeral-wrap">
          <span class="kyn-match-score__num" id="kyn-match-num">0</span><span class="kyn-match-score__pct">%</span>
        </div>
        <div class="kyn-match-score__right">
          <div class="kyn-match-score__label">match for your lifestyle</div>
          <div class="kyn-match-score__bar-track">
            <div class="kyn-match-score__bar" id="kyn-match-bar" style="width:0%"></div>
          </div>
        </div>
      </div>
      <div class="kyn-match-score__explanation">${explanation}</div>`;

    // Insert before the AI summary
    const aiSummary = sidebar.querySelector(".kyn-ai-summary");
    if (aiSummary) aiSummary.parentNode.insertBefore(el, aiSummary);

    // Animate bar and counter on next frame
    requestAnimationFrame(() => {
      el.querySelector("#kyn-match-bar").style.width = score + "%";
      animateCounter(el.querySelector("#kyn-match-num"), score);
    });
  }

  function animateCounter(el, target) {
    const duration = 700;
    const start    = performance.now();
    (function tick(now) {
      const t = Math.min((now - start) / duration, 1);
      // Cubic ease-out
      const eased = 1 - Math.pow(1 - t, 3);
      el.textContent = Math.round(eased * target);
      if (t < 1) requestAnimationFrame(tick);
    })(start);
  }

  // ─── Personalization: onboarding overlay ─────────────────────────────────

  function showOnboardingOverlay(sidebar, data, { isUpdate, onComplete, onCancel }) {
    const overlay = document.createElement("div");
    overlay.id = "kyn-overlay";
    overlay.className = "kyn-overlay";

    overlay.innerHTML = `
      <div class="kyn-overlay__panel">
        <div class="kyn-overlay__header">
          <span class="kyn-logo">KYN</span>
          <button class="kyn-overlay__x" id="kyn-overlay-x" aria-label="Close">✕</button>
        </div>

        <div class="kyn-overlay__intro">
          <div class="kyn-overlay__title">Tell us about yourself</div>
          <p class="kyn-overlay__sub">
            Answer 4 quick questions and we'll calculate your personal match score for
            <strong>${data.neighborhood}</strong> — and every other neighborhood you browse.
          </p>
        </div>

        <div class="kyn-overlay__questions">

          <div class="kyn-overlay__q" data-key="hasKids">
            <div class="kyn-overlay__q-label">
              <span class="kyn-overlay__q-num">1</span>
              Do you have (or plan to have) kids?
            </div>
            <div class="kyn-overlay__opts">
              <button class="kyn-opt" data-val="true">👨‍👧 Yes</button>
              <button class="kyn-opt" data-val="false">Not for now</button>
            </div>
          </div>

          <div class="kyn-overlay__q" data-key="commute">
            <div class="kyn-overlay__q-label">
              <span class="kyn-overlay__q-num">2</span>
              How do you get to work?
            </div>
            <div class="kyn-overlay__opts">
              <button class="kyn-opt" data-val="remote">🏠 Remote</button>
              <button class="kyn-opt" data-val="transit">🚆 Transit</button>
              <button class="kyn-opt" data-val="drive">🚗 Drive</button>
            </div>
          </div>

          <div class="kyn-overlay__q" data-key="sleepType">
            <div class="kyn-overlay__q-label">
              <span class="kyn-overlay__q-num">3</span>
              How do you sleep?
            </div>
            <div class="kyn-overlay__opts">
              <button class="kyn-opt" data-val="light">🌙 Light sleeper</button>
              <button class="kyn-opt" data-val="heavy">😴 Deep sleeper</button>
            </div>
          </div>

          <div class="kyn-overlay__q" data-key="eveningStyle">
            <div class="kyn-overlay__q-label">
              <span class="kyn-overlay__q-num">4</span>
              What's your ideal evening?
            </div>
            <div class="kyn-overlay__opts">
              <button class="kyn-opt" data-val="quiet">🛋️ Quiet night in</button>
              <button class="kyn-opt" data-val="active">🍸 Active nightlife</button>
            </div>
          </div>

        </div>

        <div class="kyn-overlay__footer">
          <button class="kyn-overlay__submit" id="kyn-overlay-submit" disabled>
            Calculate my match →
          </button>
          <button class="kyn-overlay__cancel" id="kyn-overlay-cancel">
            ${isUpdate ? "Cancel" : "Skip for now"}
          </button>
        </div>
      </div>`;

    sidebar.appendChild(overlay);

    // Track selections
    const answers = {};
    const submitBtn = overlay.querySelector("#kyn-overlay-submit");
    const REQUIRED_KEYS = ["hasKids", "commute", "sleepType", "eveningStyle"];

    overlay.querySelectorAll(".kyn-overlay__q").forEach((qEl) => {
      const key = qEl.dataset.key;
      qEl.querySelectorAll(".kyn-opt").forEach((btn) => {
        btn.addEventListener("click", () => {
          qEl.querySelectorAll(".kyn-opt").forEach(b => b.classList.remove("kyn-opt--selected"));
          btn.classList.add("kyn-opt--selected");

          let val = btn.dataset.val;
          if (val === "true")  val = true;
          if (val === "false") val = false;
          answers[key] = val;

          const allAnswered = REQUIRED_KEYS.every(k => answers[k] !== undefined);
          submitBtn.disabled = !allAnswered;
          if (allAnswered) submitBtn.classList.add("kyn-overlay__submit--ready");
        });
      });
    });

    // Submit
    submitBtn.addEventListener("click", () => {
      const prefs = {
        hasKids:      answers.hasKids,
        commute:      answers.commute,
        sleepType:    answers.sleepType,
        eveningStyle: answers.eveningStyle,
      };
      KYNPrefs.save("completed", prefs, () => {
        closeOverlay();
        onComplete(prefs);
      });
    });

    // Cancel / X
    function closeOverlay() {
      overlay.classList.add("kyn-overlay--out");
      setTimeout(() => overlay.remove(), 220);
    }

    overlay.querySelector("#kyn-overlay-x").addEventListener("click", () => {
      closeOverlay();
      onCancel();
    });

    overlay.querySelector("#kyn-overlay-cancel").addEventListener("click", () => {
      if (!isUpdate) KYNPrefs.save("skipped", null);
      closeOverlay();
      onCancel();
    });

    // Entrance animation
    requestAnimationFrame(() => overlay.classList.add("kyn-overlay--in"));
  }

  // ─── Personalization init ─────────────────────────────────────────────────

  function initPersonalization(sidebar, data) {
    if (!data) return;
    KYNPrefs.load((state, prefs) => {
      if (state === "pending") {
        insertPersonalizeBanner(sidebar, data);
      } else if (state === "completed" && prefs) {
        insertMatchScore(sidebar, data, prefs);
      }
      // "skipped" → nothing shown
    });
  }

  // ─── Chat interaction ─────────────────────────────────────────────────────

  function scrollToBottom() {
    const area = document.getElementById("kyn-scroll-area");
    if (area) area.scrollTop = area.scrollHeight;
  }

  function appendMessage(role, html) {
    const history = document.getElementById("kyn-chat-history");
    if (!history) return null;
    const wrap = document.createElement("div");
    wrap.className = `kyn-message kyn-message--${role}`;
    wrap.innerHTML = role === "bot"
      ? `<div class="kyn-message__avatar">KYN</div><div class="kyn-message__bubble">${html}</div>`
      : `<div class="kyn-message__bubble">${html}</div>`;
    history.appendChild(wrap);
    requestAnimationFrame(scrollToBottom);
    return wrap;
  }

  function showTypingIndicator() {
    return appendMessage("bot", '<span class="kyn-typing-dots"><span></span><span></span><span></span></span>');
  }

  function attachChatListeners(sidebar, data) {
    const input   = sidebar.querySelector("#kyn-chat-input");
    const sendBtn = sidebar.querySelector("#kyn-chat-send");
    if (!input || !sendBtn) return;

    let busy = false;

    function submit() {
      if (busy) return;
      const question = input.value.trim();
      if (!question) return;
      input.value = "";
      input.style.height = "auto";

      appendMessage("user", escapeHtml(question));
      busy = true;
      sendBtn.disabled = true;
      const indicator = showTypingIndicator();

      setTimeout(() => {
        indicator.remove();
        appendMessage("bot", KYNChatEngine.getResponse(question, data));
        busy = false;
        sendBtn.disabled = false;
        input.focus();
      }, 650 + Math.floor(Math.random() * 450));
    }

    sendBtn.addEventListener("click", submit);
    input.addEventListener("keydown", (e) => {
      if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); submit(); }
    });
    input.addEventListener("input", () => {
      input.style.height = "auto";
      input.style.height = Math.min(input.scrollHeight, 72) + "px";
    });
  }

  function escapeHtml(str) {
    return str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  }

  // ─── Sidebar lifecycle ────────────────────────────────────────────────────

  function attachToggleListeners(sidebar) {
    sidebar.querySelectorAll(".kyn-card__header").forEach((btn) => {
      btn.addEventListener("click", () => {
        const card   = btn.closest(".kyn-card");
        const detail = card.querySelector(".kyn-card__detail");
        const isOpen = btn.getAttribute("aria-expanded") === "true";
        btn.setAttribute("aria-expanded", String(!isOpen));
        detail.hidden = isOpen;
        card.classList.toggle("kyn-card--open", !isOpen);
      });
    });

    sidebar.querySelector("#kyn-close-btn").addEventListener("click", () => {
      sidebar.classList.add("kyn-sidebar--hidden");
      // Remove the wide margin — showRevealButton will add the narrow tab margin
      document.body.classList.remove("kyn-body-shifted");
      showRevealButton();
    });
  }

  function showRevealButton() {
    if (document.getElementById("kyn-reveal-btn")) return;

    const tab = document.createElement("button");
    tab.id = "kyn-reveal-btn";
    tab.setAttribute("aria-label", "Open KYN neighborhood panel");
    tab.title = "Know Your Neighborhood — click to open";
    tab.innerHTML = `
      <span class="kyn-tab__label">KYN</span>
      <span class="kyn-tab__arrow" aria-hidden="true">◀</span>`;

    tab.addEventListener("click", () => {
      const sidebar = document.getElementById("kyn-sidebar");

      // Animate tab out
      tab.classList.add("kyn-tab--closing");

      // Slide sidebar back in and restore full margin
      sidebar.classList.remove("kyn-sidebar--hidden");
      document.body.classList.remove("kyn-body-tabbed");
      document.body.classList.add("kyn-body-shifted");

      // Remove tab element after its exit animation finishes
      setTimeout(() => tab.remove(), 260);
    });

    document.body.appendChild(tab);

    // Switch from wide sidebar margin to slim tab margin so page content
    // slides smoothly from 340px to 28px in one CSS transition
    document.body.classList.add("kyn-body-tabbed");
  }

  // ─── Gear / settings dropdown ────────────────────────────────────────────

  let _gearOutsideHandler = null;

  function closeGearDropdown() {
    const existing = document.getElementById("kyn-gear-dropdown");
    if (existing) existing.remove();
    if (_gearOutsideHandler) {
      document.removeEventListener("click", _gearOutsideHandler, true);
      _gearOutsideHandler = null;
    }
  }

  function openGearDropdown(gearBtn, sidebar, data) {
    closeGearDropdown();

    KYNPrefs.load((state, prefs) => {
      const hasPrefs = state === "completed" && prefs;

      const dropdown = document.createElement("div");
      dropdown.id = "kyn-gear-dropdown";
      dropdown.className = "kyn-gear-dropdown";

      if (!hasPrefs) {
        dropdown.innerHTML = `
          <button class="kyn-gear-item" data-action="personalize">Personalize my match score</button>`;
      } else {
        dropdown.innerHTML = `
          <button class="kyn-gear-item" data-action="update">Update preferences</button>
          <div class="kyn-gear-divider"></div>
          <button class="kyn-gear-item kyn-gear-item--subtle" data-action="clear">Clear preferences</button>`;
      }

      const rect = gearBtn.getBoundingClientRect();
      dropdown.style.top   = (rect.bottom + 6) + "px";
      dropdown.style.right  = (window.innerWidth - rect.right) + "px";

      document.body.appendChild(dropdown);

      dropdown.querySelectorAll(".kyn-gear-item").forEach(btn => {
        btn.addEventListener("click", (e) => {
          e.stopPropagation();
          const action = btn.dataset.action;
          closeGearDropdown();

          if (action === "personalize" || action === "update") {
            const matchEl = sidebar.querySelector("#kyn-match-score");
            if (matchEl) matchEl.style.display = "none";
            showOnboardingOverlay(sidebar, data, {
              isUpdate: action === "update",
              onComplete: (newPrefs) => {
                if (matchEl) matchEl.remove();
                insertMatchScore(sidebar, data, newPrefs);
              },
              onCancel: () => {
                if (matchEl) matchEl.style.display = "";
              },
            });
          } else if (action === "clear") {
            chrome.storage.local.remove(["kyn_onboarding", "kyn_prefs"], () => {
              const matchEl = sidebar.querySelector("#kyn-match-score");
              if (matchEl) matchEl.remove();
              insertPersonalizeBanner(sidebar, data);
            });
          }
        });
      });

      _gearOutsideHandler = (e) => {
        const dd = document.getElementById("kyn-gear-dropdown");
        if (dd && !dd.contains(e.target) && e.target !== gearBtn && !gearBtn.contains(e.target)) {
          closeGearDropdown();
        }
      };
      document.addEventListener("click", _gearOutsideHandler, true);
    });
  }

  function attachGearListener(sidebar, data) {
    const gearBtn = sidebar.querySelector("#kyn-gear-btn");
    if (!gearBtn) return;
    gearBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      if (document.getElementById("kyn-gear-dropdown")) {
        closeGearDropdown();
      } else {
        openGearDropdown(gearBtn, sidebar, data);
      }
    });
  }

  function injectSidebar() {
    const addressText = extractAddressText();
    const urlSlug     = extractAddressFromUrl();
    const zipCode     = extractZipFromUrl();
    const key         = matchNeighborhoodKey(addressText, urlSlug, zipCode);
    const data        = key ? KYN_NEIGHBORHOODS[key] : null;

    const sidebar = document.createElement("div");
    sidebar.id    = "kyn-sidebar";
    sidebar.setAttribute("role", "complementary");
    sidebar.setAttribute("aria-label", "KYN Neighborhood Intelligence");

    const scrollArea = document.createElement("div");
    scrollArea.className = "kyn-scroll-area";
    scrollArea.id = "kyn-scroll-area";

    if (data) {
      const shortAddr = urlSlug
        .replace(/-chicago-il-\d+$/, "")
        .replace(/-/g, " ")
        .replace(/\b\w/g, c => c.toUpperCase())
        .substring(0, 50);

      scrollArea.innerHTML = buildScrollContent(data, shortAddr);

      const inputBar = document.createElement("div");
      inputBar.className = "kyn-chat-input-bar";
      inputBar.innerHTML = `
        <div class="kyn-chat-input-wrap">
          <textarea
            class="kyn-chat-input"
            id="kyn-chat-input"
            placeholder="Ask about ${data.neighborhood}…"
            rows="1"
            maxlength="300"
            aria-label="Ask a question about the neighborhood"
          ></textarea>
          <button class="kyn-chat-send-btn" id="kyn-chat-send" aria-label="Send question">
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
              <path d="M8 13V3M8 3L4 7M8 3l4 4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
          </button>
        </div>`;

      sidebar.appendChild(scrollArea);
      sidebar.appendChild(inputBar);
    } else {
      scrollArea.innerHTML = buildLimitedScrollContent(
        addressText.substring(0, 80) || urlSlug.replace(/-/g, " "),
        zipCode
      );
      sidebar.appendChild(scrollArea);
    }

    document.body.appendChild(sidebar);
    attachToggleListeners(sidebar);
    if (data) {
      attachChatListeners(sidebar, data);
      attachGearListener(sidebar, data);
      initPersonalization(sidebar, data);
    }
    document.body.classList.add("kyn-body-shifted");
  }

  // ─── Zillow SPA navigation ────────────────────────────────────────────────

  let lastPath = window.location.pathname;

  function handleNavigation() {
    const path = window.location.pathname;
    if (path === lastPath) return;
    lastPath = path;

    closeGearDropdown();
    const existing  = document.getElementById("kyn-sidebar");
    const revealBtn = document.getElementById("kyn-reveal-btn");
    if (existing)  existing.remove();
    if (revealBtn) revealBtn.remove();
    document.body.classList.remove("kyn-body-shifted", "kyn-body-tabbed");

    if (path.match(/\/homedetails\//)) setTimeout(injectSidebar, 800);
  }

  ["pushState", "replaceState"].forEach((method) => {
    const orig = history[method];
    history[method] = function (...args) { orig.apply(this, args); handleNavigation(); };
  });
  window.addEventListener("popstate", handleNavigation);

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", injectSidebar);
  } else {
    injectSidebar();
  }
})();
