// ─── KYN Preferences & Lifestyle Match Engine ────────────────────────────────

const KYNPrefs = (() => {

  const KEY_STATE = "kyn_onboarding";  // 'pending' | 'skipped' | 'completed'
  const KEY_PREFS = "kyn_prefs";

  // ── Chrome storage helpers ──────────────────────────────────────────────────

  function load(cb) {
    chrome.storage.local.get([KEY_STATE, KEY_PREFS], (result) => {
      cb(result[KEY_STATE] || "pending", result[KEY_PREFS] || null);
    });
  }

  function save(state, prefs, cb) {
    const data = { [KEY_STATE]: state };
    if (prefs) data[KEY_PREFS] = prefs;
    chrome.storage.local.set(data, cb || (() => {}));
  }

  // ── Weight calculation ──────────────────────────────────────────────────────
  // Each category gets a weight (importance) and optional invert flag.
  // invert=true means the user PREFERS a lower score (e.g. nightlife lover wants noise).
  // Category scores in the data: 5 = excellent/quiet/safe. 1 = poor/loud/dangerous.

  function getWeights(prefs) {
    const w = {
      noise:        { w: 1.5, invert: false },
      construction: { w: 1.0, invert: false },
      safety:       { w: 1.5, invert: false },
      schools:      { w: 1.5, invert: false },
      feel:         { w: 1.5, invert: false },
    };

    // ── Kids ──────────────────────────────────────────────────────
    if (prefs.hasKids) {
      w.schools.w  = 3.5;   // most important factor for families
      w.safety.w   = 2.5;   // safety critical with kids
      w.noise.w   += 0.5;   // kids need quiet too
      w.feel.w    += 0.5;   // community feel matters for families
    } else {
      w.schools.w  = 0.4;   // largely irrelevant without kids
    }

    // ── Sleep type ────────────────────────────────────────────────
    if (prefs.sleepType === "light") {
      w.noise.w        += 2.0;   // critical — noise ruins light sleepers
      w.construction.w += 1.0;   // early-morning jackhammers are a real issue
    } else {
      // heavy sleeper — noise less important
      w.noise.w = Math.max(0.5, w.noise.w - 0.5);
    }

    // ── Evening style ─────────────────────────────────────────────
    if (prefs.eveningStyle === "active") {
      w.feel.w += 0.5;   // nightlife/vibe matters more

      if (prefs.sleepType === "heavy") {
        // Heavy sleeper who loves nightlife: actually WANTS a noisy neighborhood.
        // Invert noise — a score of 1 (very loud) is a GOOD match for them.
        w.noise.invert  = true;
        w.noise.w      += 1.0;
      }
      // Light sleeper who loves nightlife: conflicted preferences.
      // Sleep wins for noise direction (keep normal), no extra weight.
    } else {
      // Quiet evenings: reinforce the preference for lower noise
      w.noise.w += 0.5;
    }

    // ── Commute ────────────────────────────────────────────────────
    if (prefs.commute === "remote") {
      // Home all day — daytime construction and noise hit harder
      w.noise.w        += 0.5;
      w.construction.w += 0.5;
    } else if (prefs.commute === "drive") {
      // Road construction = lane closures and parking impact
      w.construction.w += 0.5;
    }
    // Transit: no direct category impact (no transit-quality score in data)

    return w;
  }

  // ── Score calculation ───────────────────────────────────────────────────────

  function calculateMatch(neighborhoodData, prefs) {
    const weights = getWeights(prefs);

    let totalWeighted = 0;
    let totalWeight   = 0;

    for (const cat of neighborhoodData.categories) {
      const { w, invert } = weights[cat.id] || { w: 1, invert: false };
      // Normalize 1-5 score to 0.0–1.0
      let normalized = (cat.score - 1) / 4;
      if (invert) normalized = 1 - normalized;

      totalWeighted += normalized * w;
      totalWeight   += w;
    }

    return Math.round((totalWeighted / totalWeight) * 100);
  }

  // ── Explanation generator ───────────────────────────────────────────────────

  function getExplanation(score, neighborhoodData, prefs) {
    const getCat = (id) => neighborhoodData.categories.find(c => c.id === id);
    const noise        = getCat("noise");
    const construction = getCat("construction");
    const safety       = getCat("safety");
    const schools      = getCat("schools");
    const feel         = getCat("feel");

    const pos = [];
    const neg = [];

    // Noise
    if (prefs.sleepType === "light") {
      if (noise.score >= 4)      pos.push("quiet neighborhood");
      else if (noise.score === 3) neg.push("some weekend noise");
      else                        neg.push("noise may disrupt your sleep");
    } else if (prefs.eveningStyle === "active" && prefs.sleepType === "heavy") {
      if (noise.score <= 2)       pos.push("lively nightlife scene");
      else if (noise.score >= 4)  neg.push("quieter than your ideal");
    }

    // Construction — flag only if it's a real concern for this user
    const constructionMatters = prefs.commute === "remote" || prefs.sleepType === "light";
    if (constructionMatters && construction.score <= 2) {
      neg.push("active construction");
    }

    // Safety — always surfaces if notable
    if (safety.score >= 5)       pos.push("excellent safety");
    else if (safety.score >= 4)  pos.push("strong safety record");
    else if (safety.score <= 2)  neg.push("safety requires awareness");

    // Schools — only relevant for families
    if (prefs.hasKids) {
      if (schools.score >= 5)      pos.push("top-rated schools");
      else if (schools.score >= 4) pos.push("strong schools");
      else if (schools.score <= 2) neg.push("limited school options");
      else                          neg.push("average schools");
    }

    // Feel / vibe
    if (prefs.eveningStyle === "active" && feel.score >= 4) {
      pos.push("vibrant neighborhood energy");
    } else if (prefs.eveningStyle === "quiet" && feel.score >= 4) {
      pos.push("great community feel");
    }

    // Compose: for good matches emphasize positives; for bad matches lead with negatives
    const pieces = score >= 60
      ? [...pos.slice(0, 2), ...neg.slice(0, 1)]
      : [...neg.slice(0, 2), ...pos.slice(0, 1)];

    if (pieces.length === 0) {
      if (score >= 80) return "strong fit across all your priorities";
      if (score >= 60) return "decent overall fit for your lifestyle";
      return "several factors conflict with your profile";
    }

    return pieces.join(" · ");
  }

  // ── Color tier ──────────────────────────────────────────────────────────────

  function scoreTier(score) {
    if (score >= 80) return "green";
    if (score >= 60) return "amber";
    return "red";
  }

  return { load, save, calculateMatch, getExplanation, scoreTier };

})();
